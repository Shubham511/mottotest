import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-medicine-detials',
  templateUrl: './medicine-detials.component.html',
  styleUrls: ['./medicine-detials.component.css']
})
export class MedicineDetialsComponent implements OnInit {

  constructor(private _router:Router) { }

  ngOnInit() {
   
  }
  
  gologin(){
    this._router.navigate(['/login']);
  }

  goaddfind(){
    this._router.navigate(['/add-find']);
  }
  
  goConsultion(){
    this._router.navigate(['/consultion']);
  }

  goreviewdet(){
    this._router.navigate(['/review-det']);
  }

}
